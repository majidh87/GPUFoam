wclean
rm discretizationKernel.o
rm ldu2csr.o
